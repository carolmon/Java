import java.util.Scanner;

public class Avaliacao1 {
	public static void main(String[] args) {
		Scanner scr1 = new Scanner(System.in);
		int tamanhoQuadrado = scr1.nextInt();
		int linha;
		int coluna;
		int novoQuadrado = tamanhoQuadrado / 2;
		char caracter = 'X';
		String espaso = " ";
		if (tamanhoQuadrado <= 1 || tamanhoQuadrado % 2 == 0) {
			System.out.println("Numero invalido");
		} else {
			for (linha = 0; linha < tamanhoQuadrado; linha++) {// for linha

				for (coluna = 0; coluna < tamanhoQuadrado; coluna++) { // for coluna

					if (linha > 0 && linha < novoQuadrado && coluna > 0 && coluna < novoQuadrado) {// espaso novo
																									// quadrado
						System.out.print(espaso);
					} else if (linha <= novoQuadrado && coluna <= novoQuadrado) {// caracter novo quadradp
						System.out.print(caracter);
					} else if (linha > 0 && linha < tamanhoQuadrado - 1 && coluna > 0 && coluna < tamanhoQuadrado - 1) {// espaso
																														// quadrado
						System.out.print(espaso);
					}

					else {// caracter quadrado
						System.out.print(caracter);
					}

				}
				System.out.println();

			}
		}
	}
}
